package tp1;

public class Exe5 {
	//Affichage dans l'ordre croissant

	public static void main(String[] args) {

	}
}
