package tp1;
import java.util.Scanner;

public class Exe3 {
	//Année bissextile

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);



		sc.close();
	}
}
