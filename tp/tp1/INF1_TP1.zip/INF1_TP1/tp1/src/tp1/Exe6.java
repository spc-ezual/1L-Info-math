package tp1;

public class Exe6 {
	//Conversion secondes

	public static void main(String[] args) {

	}
}
