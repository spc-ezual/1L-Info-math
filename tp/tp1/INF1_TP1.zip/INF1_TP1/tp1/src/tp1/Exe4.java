package tp1;

public class Exe4 {
	//Parité d'une somme

	public static void main(String[] args) {

	}
}
